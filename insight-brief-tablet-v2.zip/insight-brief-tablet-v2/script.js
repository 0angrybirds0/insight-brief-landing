const form = document.querySelector('#leadForm');
const nickname = document.querySelector('#nickname');
const contact = document.querySelector('#contact');
const contactLabel = document.querySelector('#contactLabel');
const privacyToggle = document.querySelector('#privacyToggle');
const privacyDetail = document.querySelector('#privacyDetail');
const successMessage = document.querySelector('#successMessage');

const methodSettings = {
  email: { label: '이메일 주소', type: 'email', placeholder: 'name@example.com', autocomplete: 'email' },
  phone: { label: '전화번호', type: 'tel', placeholder: '010-1234-5678', autocomplete: 'tel' },
  instagram: { label: '인스타그램 아이디', type: 'text', placeholder: '@your_id', autocomplete: 'off' }
};

document.querySelectorAll('input[name="method"]').forEach((radio) => {
  radio.addEventListener('change', () => {
    const setting = methodSettings[radio.value];
    contactLabel.innerHTML = `${setting.label} <em>필수</em>`;
    contact.type = setting.type;
    contact.placeholder = setting.placeholder;
    contact.autocomplete = setting.autocomplete;
    contact.value = '';
    document.querySelector('#contactError').textContent = '';
    successMessage.hidden = true;
  });
});

privacyToggle.addEventListener('click', () => {
  privacyDetail.hidden = !privacyDetail.hidden;
  privacyToggle.textContent = privacyDetail.hidden ? '내용 보기' : '내용 닫기';
  privacyToggle.setAttribute('aria-expanded', String(!privacyDetail.hidden));
});

function isValidContact(method, value) {
  if (method === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  if (method === 'phone') return /^[0-9+()\-\s]{8,20}$/.test(value);
  return /^@?[A-Za-z0-9._]{2,30}$/.test(value);
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  successMessage.hidden = true;

  const method = new FormData(form).get('method');
  const consent = document.querySelector('#consent');
  let valid = true;

  document.querySelector('#nicknameError').textContent = '';
  document.querySelector('#contactError').textContent = '';
  document.querySelector('#consentError').textContent = '';

  if (!nickname.value.trim()) {
    document.querySelector('#nicknameError').textContent = '닉네임을 입력해 주세요.';
    valid = false;
  }
  if (!contact.value.trim()) {
    document.querySelector('#contactError').textContent = '연락처를 입력해 주세요.';
    valid = false;
  } else if (!isValidContact(method, contact.value.trim())) {
    document.querySelector('#contactError').textContent = '선택한 연락 방법에 맞게 입력해 주세요.';
    valid = false;
  }
  if (!consent.checked) {
    document.querySelector('#consentError').textContent = '개인정보 수집 및 이용에 동의해 주세요.';
    valid = false;
  }

  if (!valid) {
    if (!nickname.value.trim()) nickname.focus();
    else if (!contact.value.trim() || !isValidContact(method, contact.value.trim())) contact.focus();
    else consent.focus();
    return;
  }

  successMessage.hidden = false;
  successMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
});
